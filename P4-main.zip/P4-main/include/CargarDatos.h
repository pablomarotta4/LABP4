#ifndef CARGADATOS_H
#define CARGADATOS_H

void cargarDatos();

#endif